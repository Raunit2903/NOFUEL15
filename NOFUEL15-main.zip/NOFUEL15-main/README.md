# NOFUEL15(PATENT FILED)
An Automated Smart fueling System
https://www.canva.com/design/DAGmULoFcy0/X-tWqsIlXCD3lTJWhvyDZg/edit?utm_content=DAGmULoFcy0&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton
 app apk link https://api.flutlab.io/projects/2564896/download-app?key=d6w4qnqif61ndzofbies&target=android-arm64

